# 里程碑时间线

**项目：** RISC-V / LoCoMo Dynamic Memory Management  
**课程：** Software Requirements Engineering (2026)  
**最后更新：** 2026-10-10

> 核心要求：每个里程碑至少 2 轮迭代，且计划中包含 buffer。

| 里程碑 | 迭代 | 行动项 | 开始 | 结束 | Buffer |
|--------|------|--------|------|------|--------|
| M1 Team Workflow | Iter 1 | 起草团队规则、角色分配、初版计划 | 09/25 | 09/28 | 09/29–09/30 (2天) |
|  | Iter 2 | 评审规则、修改文档、定稿 PDF、打包 ZIP | 10/01 | 10/05 | 10/06–10/08 (3天) |
| M2 Proposal | Iter 1 | 撰写愿景、范围、功能路线图、初版 slides | 09/29 | 10/03 | 10/04–10/05 (2天) |
|  | Iter 2 | 内部预演、修改提案、生成 PDF | 10/06 | 10/08 | 10/09 (1天) |
| M3 SRS | Iter 1 | 需求规格草稿（Memory 字段、状态关系定义） | 10/11 | 10/12 | 10/13 (1天) |
|  | Iter 2 | 组内评审、修改、最终版 SRS PDF | 10/14 | 10/16 | 10/17 (1天) |
| M4 Mid-term | Iter 1 | 系统设计、核心编码、初步测试、展示草稿 | 10/18 | 10/19 | 10/20 (1天) |
|  | Iter 2 | 集成测试、Bug 修复、展示排练、终版 PDF | 10/21 | 10/23 | 10/24 (1天) |
| M5 Final | Iter 1 | 完整系统测试、实验分析、报告草稿 | 10/25 | 11/01 | 11/02 (1天) |
|  | Iter 2 | 最终评测、报告定稿、展示排练、提交 ZIP | 11/03 | 11/08 | 11/09 (1天) |

## 关键时间节点

| 里程碑 | 交付物 | 截止日期 |
|--------|--------|----------|
| M1 & M2 | PDF + process ZIP | 24:00 Oct 10, 2026 |
| M3 | SRS PDF + process ZIP | 24:00 Oct 24, 2026 |
| M4 | Mid-term Presentation PDF + process ZIP | 24:00 Oct 24, 2026 |
| M5 | Final Presentation PDF + Final Report | 24:00 Nov 9, 2026 |

## 交付物命名规范
按课程要求：PROJECT-MILESTONE[n]-[team_id]-RISC-V.pdf 和 .zip
